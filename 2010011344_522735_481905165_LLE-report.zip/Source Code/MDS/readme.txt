hole.m
function hole:
requires a square matrix as the input
outputs a square matrix with entries (i,j) deleted when i is equal to j mod 2.

hw2.m
script
requires Y and p
allocate two structures, resulting rmsd is the difference of them

random_structure.m
function random_structure:
requires a real number sigma denoting the variance
output a random structure

memo.m
script
test the accuracy of MDS under Euclidean metric
