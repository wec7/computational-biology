
for sigma = 0:30
    tmp(sigma+1) =0;
    for i = 1:10
        [c,f,p] = random_structure(sigma/10);
        %[Y,eigvals] = cmdscale(f); % Classical MDS

        r = hole(f);
        %r = f;

        [Y, stree] = mdscale(r,3,'start','random','criterion','metricstress');

        hw2;
        x(sigma+1) = sigma/10;
        tmp(sigma+1) = tmp(sigma+1)+rmsd;
    end
end
%lle_eval('C:\Users\wangsincos\Desktop\a1.pdb', 'C:\Users\wangsincos\Desktop\a2.pdb', 0,A, B);