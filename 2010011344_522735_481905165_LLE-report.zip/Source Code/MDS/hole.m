function r = hole(f)
    r = f;
    n = size(f,1);
    for i = 1 : n
        for j = 1 : n
            if (mod(i, 2) == mod(j, 2) && i ~= j)
                r(i,j) = NaN;
            end
        end
    end
end