
function [c,f,p] = random_structure(sigma)
N = 75;
f = zeros(N, N);
p = zeros(3, N);
for i = 2 : N
    p(:,i) = p(:,i-1) + normrnd(0, 1, [3,1]);
end
%plot3(p(1,:),p(2,:),p(3,:),'b*-');
c = zeros(N,N);
M = 10;
sig = 10;
for i = 1 : N
    for j = 1 : N
        %if (i~=j) 
        %    c(i,j) = M / norm(p(:,i)-p(:,j), 'fro');+normrnd(0,.1);
        %end
        if (i<j)
             c(i,j)=normrnd(0,sigma);
            f(i,j) =  norm(p(:,i)-p(:,j), 'fro')+ c(i,j);
            if f(i,j)<0 
                f(i,j)=0;
            end
        elseif (i==j)
            f(i,j) = 0;
        else 
            f(i,j) = f(j,i);
            c(i,j) = c(j,i);
        end
    end
end