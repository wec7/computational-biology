lle_chroma.m
implementation of LLE algorithm

lle_eval.m
input/output wrapper

random_structure.m
function random_structure:
requires a real number sigma denoting the variance
output a random structure
