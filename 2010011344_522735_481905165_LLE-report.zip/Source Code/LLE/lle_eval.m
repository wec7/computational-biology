function lle_eval()
    % Data can be read from PDB or generated randomly
    %freq = readPDB(inputfile);
    [freq,X] = random_structure(25);
    
    % For different K's
    Y1 = lle_chroma(freq,3);
    Y2 = lle_chroma(freq,7);
    Y3 = lle_chroma(freq,15);
    
    % Drawing
    subplot(2,2,1)
    plot3(X(1,:),X(2,:),X(3,:),'b*-')
    title('Simulated Structure, N = 25');
    subplot(2,2,2)
    plot3(Y1(1,:),Y1(2,:),Y1(3,:),'b*-')
    title('LLE embedding, K = 3');
    subplot(2,2,3)
    plot3(Y2(1,:),Y2(2,:),Y2(3,:),'b*-')
    title('LLE embedding, K = 7');
    subplot(2,2,4)
    plot3(Y3(1,:),Y3(2,:),Y3(3,:),'b*-')
    title('LLE embedding, K = 15');
    
    % Output
    printPDB('random.pdb', X);
    printPDB('out3.pdb', Y1);
    printPDB('out7.pdb', Y2);
    printPDB('out15.pdb', Y3);
end

% simple implementation to read PDB files

function freq = readPDB(filename)
    input = importdata(filename);
    data = input.data;
    first = min(min(data(:,1:2)))-1;
    last = max(max(data(:,1:2)));
    N = last-first;
    freq = zeros(N);
    for i=1:length(data)
        freq(data(i,1)-first,data(i,2)-first) = data(i,3);
    end
    freq = freq + freq';
end

% simple implementation to create PDB files

function printPDB(filename, Y)
    fid=fopen(filename,'w');
    fmt = 'ATOM   % 4d C    LIG A        % 8.3f% 8.3f% 8.3f  1.00 75.00    \n';
    fprintf(fid,fmt, [(1:length(Y)); Y]);
    fprintf(fid,'CONECT % 4d% 4d\n', [(1:length(Y)-1);(2:length(Y))]);
	fprintf(fid,'END');
end