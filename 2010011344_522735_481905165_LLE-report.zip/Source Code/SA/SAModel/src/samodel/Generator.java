package samodel;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Random;

public class Generator {
	static private Random rand = new Random();
	private int N;
	double R;
	private double[][] dist;
	static Solution RandSolution(int N) {
		Solution s = new Solution(N);
		for (int i = 0; i < N; i++) {
			s.position[i][0] = (rand.nextDouble() * 2 - 1.0);
			s.position[i][1] = (rand.nextDouble() * 2 - 1.0);
			s.position[i][2] = (rand.nextDouble() * 2 - 1.0);
		}
		return s;
	}
	
	public Generator(Solution s) {
		R = 0;
		this.N = s.position.length;
		dist = new double[N][N];
		for (int i = 0; i < N; i++) {
			for (int j = 0; j < N; j++) {
				dist[i][j] = s.dist(i,j);
				R = Math.max(R, dist[i][j]);
			}
		}
	}
	
	public Generator(String filename) {
		R = 0;
		try{
			File file = new File(filename);
			if (!file.exists() || file.isDirectory())
				throw new FileNotFoundException();
			BufferedReader br = new BufferedReader(new FileReader(file));
			String line = br.readLine();
			int start =Integer.MAX_VALUE, end = Integer.MIN_VALUE;
			while ((line = br.readLine()) != null) {
				String words[] = line.split("\t");
				start = Math.min(start, Integer.valueOf(words[0]));
				end = Math.max(end, Integer.valueOf(words[1]));
			}
			N = (end - start + 1) / 2;
			dist = new double[N][N];
			br.close();
			br = new BufferedReader(new FileReader(file));
			line = br.readLine();
			while ((line = br.readLine()) != null) {
				String words[] = line.split("\t");
				int i = (Integer.valueOf(words[0])-start) / 2;
				int j = (Integer.valueOf(words[1])-start-1) / 2;
				if (i != j) {
					double d = Double.valueOf(words[2]);
					if (d > 0.0) {
						dist[i][j] = 1 / d;
						R = Math.max(R,d);
					}
				}
			}
			br.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public Solution initSolution() {
		Solution s = new Solution(N);
		double score = 0;
		for (int i = 0; i < N; i++) {
			for (int j = 0; j < N; j++) {
				if (dist[i][j] > 0) {
					score += sqr((s.dist(i,j) - dist[i][j]) / dist[i][j]);
				}
			}
		}
		s.score = Math.sqrt(score);
		return s;
	}

	public Solution genSolution(Solution os) {
		Solution ns = new Solution(os);
		int pos = (int) (Math.random() * N);
		ns.position[pos][0] += (rand.nextDouble() * 2 - 1.0) * R;
		ns.position[pos][1] += (rand.nextDouble() * 2 - 1.0) * R;
		ns.position[pos][2] += (rand.nextDouble() * 2 - 1.0) * R;
		updateScore(ns, os, pos);
		return ns;
	}

	public int step() {
		return N * 10000;
	}
	
	private void updateScore(Solution ns, Solution os, int pos) {
		double score = os.score * os.score;
		for (int i = 0; i < N; i++) {
			if (dist[i][pos] > 0) {
				score -= sqr((os.dist(i,pos) - dist[i][pos]) / dist[i][pos]);
				score += sqr((ns.dist(i,pos) - dist[i][pos]) / dist[i][pos]);
			}
			if (dist[pos][i] > 0) {
				score -= sqr((os.dist(i,pos) - dist[pos][i]) / dist[pos][i]);
				score += sqr((ns.dist(i,pos) - dist[pos][i]) / dist[pos][i]);
			}
		}
		ns.score = Math.sqrt(score);
	}
	
	private double sqr(double a) {
		return a * a;
	}
}
