package samodel;

public class Data {

}
