package samodel;

import java.io.*;

public class SACore {
	static void printPDB(Solution s, String filename) {
		String line = "ATOM   % 4d C    LIG A        % 8.3f% 8.3f% 8.3f  1.00 75.00    \n";
		try {
			PrintWriter pw = new PrintWriter(new OutputStreamWriter(
					new FileOutputStream(filename)));
			int len = s.position.length;
			for (int i = 0; i < len; i++) {
				pw.printf(line, i + 1, s.position[i][0], s.position[i][1],
						s.position[i][2]);
			}
			for (int i = 1; i < len; i++) {
				pw.printf("CONECT % 4d% 4d\n", i, i + 1);
			}
			pw.println("END");
			pw.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	static Solution SimAnn(Generator gen) {
		double t = 100000, score = 0, mins;
		Solution s = gen.initSolution();
		mins = s.score;
		Solution ms = s;
		while (score != s.score) {
			score = s.score;
			for (int i = gen.step(); i > 0; i--) {
				Solution ts = gen.genSolution(s);
				double dscore = s.score - ts.score;
				if (ts.score < mins) {
					mins = ts.score;
					ms = ts;
					System.out.println(mins);
				}
				if (dscore > 0
						|| (dscore < 0 && Math.random() < Math.exp(dscore / t))) {
					s = ts;
				}
			}
			t *= 0.92;
		}
		ms.normalize();
		return ms;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			if (args[0].equalsIgnoreCase("-r")) {
				int n = Integer.valueOf(args[1]);
				Solution origin = Generator.RandSolution(n);
				Generator gen = new Generator(origin);
				Solution s = SimAnn(gen);
				System.out.println(s.score);
				printPDB(origin, "origin.pdb");
				printPDB(s, "evaluate.pdb");
				return;
			}
			if (args[0].equalsIgnoreCase("-f")) {
				Generator gen = new Generator(args[1]);
				Solution s = SimAnn(gen);
				System.out.println(s.score);
				printPDB(s, "output.pdb");
				return;
			}
		} catch (Exception e) {
			System.out.println("Usage:\n"
					+ "\"-r length\" for randomly generated constraint\n"
					+ "\"-f filename\" for specific file");
		}
	}

}
