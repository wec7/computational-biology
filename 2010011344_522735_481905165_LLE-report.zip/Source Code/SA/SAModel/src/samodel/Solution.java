package samodel;

public class Solution {
	public Solution(Solution s) {
		int len = s.position.length;
		position = new double[len][3];
		for (int i = 0; i < len; i++) {
			position[i][0] = s.position[i][0];
			position[i][1] = s.position[i][1];
			position[i][2] = s.position[i][2];
		}
		score = s.score;
	}

	public Solution(int N) {
		position = new double[N][3];
		score = 0;
	}

	public double position[][];
	public double score;

	public double dist(int i, int p) {
		return i == p ? 0.0 : Math.sqrt((position[i][0] - position[p][0])
				* (position[i][0] - position[p][0])
				+ (position[i][1] - position[p][1])
				* (position[i][1] - position[p][1])
				+ (position[i][2] - position[p][2])
				* (position[i][2] - position[p][2]));
	}
	
	public void normalize() {
		double min[] = new double[3];
		min[0] = position[0][0];
		min[1] = position[0][1];
		min[2] = position[0][2];
		for (int i = 1; i < position.length; i++) {
			min[0] = Math.min(min[0], position[i][0]);
			min[1] = Math.min(min[1], position[i][1]);
			min[2] = Math.min(min[2], position[i][2]);
		}
		for (int i = 0; i < position.length; i++) {
			position[i][0] -= (min[0] - 1);
			position[i][1] -= (min[1] - 1);
			position[i][2] -= (min[2] - 1);
		}
	}

}
